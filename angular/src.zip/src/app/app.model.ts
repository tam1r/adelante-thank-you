export enum AppView {
  addAccount = 'addAccount',
};
export type AppViewLiteral = keyof typeof AppView;
